let handler = async m => m.reply(`
╭─「 Donasi • Pulsa •Dana •Ovo 」
│ • Indosat Ooredoo [085719716425]
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
